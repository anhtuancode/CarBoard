﻿namespace GUI
{
    partial class ViewContract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label13 = new Label();
            txt_birth = new DateTimePicker();
            txt_driver_id = new TextBox();
            label2 = new Label();
            txt_address = new RichTextBox();
            txt_phone = new TextBox();
            txt_identifier = new TextBox();
            cb_gender = new ComboBox();
            label7 = new Label();
            label3 = new Label();
            txt_name = new TextBox();
            lb_km = new Label();
            label5 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label1 = new Label();
            gb_car = new GroupBox();
            img_car = new PictureBox();
            groupBox2 = new GroupBox();
            txt_end_time = new TextBox();
            txt_start_time = new MaskedTextBox();
            txt_pre_id = new TextBox();
            label20 = new Label();
            label11 = new Label();
            label12 = new Label();
            txt_end_date = new DateTimePicker();
            label10 = new Label();
            label9 = new Label();
            txt_start_date = new DateTimePicker();
            groupBox3 = new GroupBox();
            cb_pre_payment_method = new ComboBox();
            txt_pre_status = new TextBox();
            txt_pre_prices = new TextBox();
            label14 = new Label();
            label8 = new Label();
            label6 = new Label();
            gb_post_contract = new GroupBox();
            cb_car_status = new ComboBox();
            lb_car_status = new Label();
            btn_exit = new Button();
            btn_create_post_contract = new Button();
            txt_note = new RichTextBox();
            label19 = new Label();
            txt_extra_charge = new TextBox();
            label15 = new Label();
            cb_post_payment_method = new ComboBox();
            txt_post_id = new TextBox();
            label17 = new Label();
            label18 = new Label();
            label16 = new Label();
            cb_payment_type = new ComboBox();
            groupBox1.SuspendLayout();
            panel1.SuspendLayout();
            gb_car.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)img_car).BeginInit();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            gb_post_contract.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cb_payment_type);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(txt_birth);
            groupBox1.Controls.Add(txt_driver_id);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txt_address);
            groupBox1.Controls.Add(txt_phone);
            groupBox1.Controls.Add(txt_identifier);
            groupBox1.Controls.Add(cb_gender);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txt_name);
            groupBox1.Controls.Add(lb_km);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Location = new Point(15, 81);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(726, 220);
            groupBox1.TabIndex = 74;
            groupBox1.TabStop = false;
            groupBox1.Text = "Customer infomations";
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = SystemColors.ActiveCaptionText;
            label13.Location = new Point(22, 84);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(50, 20);
            label13.TabIndex = 94;
            label13.Text = "Birth:";
            // 
            // txt_birth
            // 
            txt_birth.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_birth.CalendarFont = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            txt_birth.Enabled = false;
            txt_birth.Format = DateTimePickerFormat.Short;
            txt_birth.Location = new Point(111, 84);
            txt_birth.Margin = new Padding(2);
            txt_birth.Name = "txt_birth";
            txt_birth.Size = new Size(221, 27);
            txt_birth.TabIndex = 2;
            // 
            // txt_driver_id
            // 
            txt_driver_id.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_driver_id.Enabled = false;
            txt_driver_id.ForeColor = SystemColors.WindowText;
            txt_driver_id.Location = new Point(450, 84);
            txt_driver_id.Margin = new Padding(4, 5, 4, 5);
            txt_driver_id.Name = "txt_driver_id";
            txt_driver_id.Size = new Size(250, 27);
            txt_driver_id.TabIndex = 6;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(351, 86);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 91;
            label2.Text = "Driver ID:";
            // 
            // txt_address
            // 
            txt_address.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_address.Enabled = false;
            txt_address.Location = new Point(450, 130);
            txt_address.Margin = new Padding(2);
            txt_address.Name = "txt_address";
            txt_address.Size = new Size(250, 27);
            txt_address.TabIndex = 7;
            txt_address.Text = "";
            // 
            // txt_phone
            // 
            txt_phone.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_phone.Enabled = false;
            txt_phone.Location = new Point(111, 173);
            txt_phone.Margin = new Padding(2);
            txt_phone.Name = "txt_phone";
            txt_phone.Size = new Size(221, 27);
            txt_phone.TabIndex = 4;
            // 
            // txt_identifier
            // 
            txt_identifier.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_identifier.Enabled = false;
            txt_identifier.Location = new Point(450, 34);
            txt_identifier.Margin = new Padding(2);
            txt_identifier.Name = "txt_identifier";
            txt_identifier.Size = new Size(250, 27);
            txt_identifier.TabIndex = 5;
            // 
            // cb_gender
            // 
            cb_gender.AllowDrop = true;
            cb_gender.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_gender.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_gender.Enabled = false;
            cb_gender.FormattingEnabled = true;
            cb_gender.Items.AddRange(new object[] { "Male", "Female" });
            cb_gender.Location = new Point(111, 129);
            cb_gender.Margin = new Padding(2);
            cb_gender.Name = "cb_gender";
            cb_gender.Size = new Size(221, 28);
            cb_gender.TabIndex = 3;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(351, 132);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(76, 20);
            label7.TabIndex = 85;
            label7.Text = "Address:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(20, 173);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 84;
            label3.Text = "Phone:";
            // 
            // txt_name
            // 
            txt_name.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_name.Enabled = false;
            txt_name.ForeColor = SystemColors.WindowText;
            txt_name.Location = new Point(111, 39);
            txt_name.Margin = new Padding(4, 5, 4, 5);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(221, 27);
            txt_name.TabIndex = 1;
            // 
            // lb_km
            // 
            lb_km.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lb_km.AutoSize = true;
            lb_km.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_km.ForeColor = SystemColors.ActiveCaptionText;
            lb_km.Location = new Point(351, 36);
            lb_km.Margin = new Padding(4, 0, 4, 0);
            lb_km.Name = "lb_km";
            lb_km.Size = new Size(78, 20);
            lb_km.TabIndex = 71;
            lb_km.Text = "Identifier:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(20, 131);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(69, 20);
            label5.TabIndex = 70;
            label5.Text = "Gender:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(22, 38);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(58, 20);
            label4.TabIndex = 69;
            label4.Text = "Name:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(1, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1301, 74);
            panel1.TabIndex = 75;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(534, 20);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(234, 39);
            label1.TabIndex = 2;
            label1.Text = "View contract";
            // 
            // gb_car
            // 
            gb_car.Controls.Add(img_car);
            gb_car.Location = new Point(754, 81);
            gb_car.Margin = new Padding(2);
            gb_car.Name = "gb_car";
            gb_car.Padding = new Padding(2);
            gb_car.Size = new Size(241, 219);
            gb_car.TabIndex = 77;
            gb_car.TabStop = false;
            gb_car.Text = "Car";
            // 
            // img_car
            // 
            img_car.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            img_car.Location = new Point(20, 28);
            img_car.Margin = new Padding(2);
            img_car.Name = "img_car";
            img_car.Size = new Size(204, 167);
            img_car.TabIndex = 72;
            img_car.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txt_end_time);
            groupBox2.Controls.Add(txt_start_time);
            groupBox2.Controls.Add(txt_pre_id);
            groupBox2.Controls.Add(label20);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(txt_end_date);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(txt_start_date);
            groupBox2.Location = new Point(1012, 81);
            groupBox2.Margin = new Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(2);
            groupBox2.Size = new Size(273, 288);
            groupBox2.TabIndex = 78;
            groupBox2.TabStop = false;
            groupBox2.Text = "Rental infomations";
            // 
            // txt_end_time
            // 
            txt_end_time.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_end_time.Enabled = false;
            txt_end_time.ForeColor = SystemColors.WindowText;
            txt_end_time.Location = new Point(100, 179);
            txt_end_time.Margin = new Padding(4, 5, 4, 5);
            txt_end_time.Name = "txt_end_time";
            txt_end_time.Size = new Size(162, 27);
            txt_end_time.TabIndex = 102;
            // 
            // txt_start_time
            // 
            txt_start_time.Location = new Point(100, 96);
            txt_start_time.Margin = new Padding(2);
            txt_start_time.Name = "txt_start_time";
            txt_start_time.Size = new Size(162, 27);
            txt_start_time.TabIndex = 101;
            // 
            // txt_pre_id
            // 
            txt_pre_id.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_pre_id.Enabled = false;
            txt_pre_id.ForeColor = SystemColors.WindowText;
            txt_pre_id.Location = new Point(100, 224);
            txt_pre_id.Margin = new Padding(4, 5, 4, 5);
            txt_pre_id.Name = "txt_pre_id";
            txt_pre_id.Size = new Size(162, 27);
            txt_pre_id.TabIndex = 99;
            // 
            // label20
            // 
            label20.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label20.AutoSize = true;
            label20.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = SystemColors.ActiveCaptionText;
            label20.Location = new Point(9, 226);
            label20.Margin = new Padding(4, 0, 4, 0);
            label20.Name = "label20";
            label20.Size = new Size(78, 20);
            label20.TabIndex = 100;
            label20.Text = "Contract:";
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = SystemColors.ActiveCaptionText;
            label11.Location = new Point(8, 182);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(80, 20);
            label11.TabIndex = 98;
            label11.Text = "End time:";
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = SystemColors.ActiveCaptionText;
            label12.Location = new Point(8, 139);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(80, 20);
            label12.TabIndex = 96;
            label12.Text = "End date:";
            // 
            // txt_end_date
            // 
            txt_end_date.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_end_date.Format = DateTimePickerFormat.Short;
            txt_end_date.Location = new Point(100, 138);
            txt_end_date.Margin = new Padding(2);
            txt_end_date.Name = "txt_end_date";
            txt_end_date.Size = new Size(162, 27);
            txt_end_date.TabIndex = 10;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(8, 98);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(87, 20);
            label10.TabIndex = 94;
            label10.Text = "Start time:";
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(8, 55);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(87, 20);
            label9.TabIndex = 92;
            label9.Text = "Start date:";
            // 
            // txt_start_date
            // 
            txt_start_date.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_start_date.Format = DateTimePickerFormat.Short;
            txt_start_date.Location = new Point(100, 53);
            txt_start_date.Margin = new Padding(2);
            txt_start_date.Name = "txt_start_date";
            txt_start_date.Size = new Size(162, 27);
            txt_start_date.TabIndex = 8;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(cb_pre_payment_method);
            groupBox3.Controls.Add(txt_pre_status);
            groupBox3.Controls.Add(txt_pre_prices);
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label6);
            groupBox3.Location = new Point(15, 304);
            groupBox3.Margin = new Padding(2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(2);
            groupBox3.Size = new Size(980, 64);
            groupBox3.TabIndex = 79;
            groupBox3.TabStop = false;
            groupBox3.Text = "Control";
            // 
            // cb_pre_payment_method
            // 
            cb_pre_payment_method.AllowDrop = true;
            cb_pre_payment_method.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_pre_payment_method.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_pre_payment_method.Enabled = false;
            cb_pre_payment_method.FormattingEnabled = true;
            cb_pre_payment_method.Items.AddRange(new object[] { "Banking", "Cast payment" });
            cb_pre_payment_method.Location = new Point(167, 26);
            cb_pre_payment_method.Margin = new Padding(2);
            cb_pre_payment_method.Name = "cb_pre_payment_method";
            cb_pre_payment_method.Size = new Size(200, 28);
            cb_pre_payment_method.TabIndex = 98;
            // 
            // txt_pre_status
            // 
            txt_pre_status.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_pre_status.Enabled = false;
            txt_pre_status.Location = new Point(434, 26);
            txt_pre_status.Margin = new Padding(2);
            txt_pre_status.Name = "txt_pre_status";
            txt_pre_status.Size = new Size(221, 27);
            txt_pre_status.TabIndex = 93;
            // 
            // txt_pre_prices
            // 
            txt_pre_prices.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_pre_prices.Enabled = false;
            txt_pre_prices.Location = new Point(736, 25);
            txt_pre_prices.Margin = new Padding(2);
            txt_pre_prices.Name = "txt_pre_prices";
            txt_pre_prices.Size = new Size(221, 27);
            txt_pre_prices.TabIndex = 91;
            // 
            // label14
            // 
            label14.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor = SystemColors.ActiveCaptionText;
            label14.Location = new Point(666, 28);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(62, 20);
            label14.TabIndex = 92;
            label14.Text = "Prices:";
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(371, 28);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(62, 20);
            label8.TabIndex = 90;
            label8.Text = "Status:";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(23, 27);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(139, 20);
            label6.TabIndex = 88;
            label6.Text = "Payment method:";
            // 
            // gb_post_contract
            // 
            gb_post_contract.Controls.Add(cb_car_status);
            gb_post_contract.Controls.Add(lb_car_status);
            gb_post_contract.Controls.Add(btn_exit);
            gb_post_contract.Controls.Add(btn_create_post_contract);
            gb_post_contract.Controls.Add(txt_note);
            gb_post_contract.Controls.Add(label19);
            gb_post_contract.Controls.Add(txt_extra_charge);
            gb_post_contract.Controls.Add(label15);
            gb_post_contract.Controls.Add(cb_post_payment_method);
            gb_post_contract.Controls.Add(txt_post_id);
            gb_post_contract.Controls.Add(label17);
            gb_post_contract.Controls.Add(label18);
            gb_post_contract.Location = new Point(15, 372);
            gb_post_contract.Margin = new Padding(2);
            gb_post_contract.Name = "gb_post_contract";
            gb_post_contract.Padding = new Padding(2);
            gb_post_contract.Size = new Size(1270, 274);
            gb_post_contract.TabIndex = 80;
            gb_post_contract.TabStop = false;
            gb_post_contract.Text = "Post contract";
            // 
            // cb_car_status
            // 
            cb_car_status.AllowDrop = true;
            cb_car_status.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_car_status.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_car_status.FormattingEnabled = true;
            cb_car_status.Items.AddRange(new object[] { "Ready", "Maintenance" });
            cb_car_status.Location = new Point(820, 162);
            cb_car_status.Margin = new Padding(2);
            cb_car_status.Name = "cb_car_status";
            cb_car_status.Size = new Size(364, 28);
            cb_car_status.TabIndex = 108;
            // 
            // lb_car_status
            // 
            lb_car_status.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lb_car_status.AutoSize = true;
            lb_car_status.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_car_status.ForeColor = SystemColors.ActiveCaptionText;
            lb_car_status.Location = new Point(664, 164);
            lb_car_status.Margin = new Padding(4, 0, 4, 0);
            lb_car_status.Name = "lb_car_status";
            lb_car_status.Size = new Size(92, 20);
            lb_car_status.TabIndex = 109;
            lb_car_status.Text = "Car status:";
            // 
            // btn_exit
            // 
            btn_exit.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_exit.BackColor = Color.SteelBlue;
            btn_exit.Cursor = Cursors.Hand;
            btn_exit.ForeColor = SystemColors.ButtonHighlight;
            btn_exit.Location = new Point(903, 209);
            btn_exit.Margin = new Padding(2);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(167, 47);
            btn_exit.TabIndex = 107;
            btn_exit.Text = "Exit";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // btn_create_post_contract
            // 
            btn_create_post_contract.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_create_post_contract.BackColor = Color.SteelBlue;
            btn_create_post_contract.Cursor = Cursors.Hand;
            btn_create_post_contract.ForeColor = SystemColors.ButtonHighlight;
            btn_create_post_contract.Location = new Point(1081, 209);
            btn_create_post_contract.Margin = new Padding(2);
            btn_create_post_contract.Name = "btn_create_post_contract";
            btn_create_post_contract.Size = new Size(167, 47);
            btn_create_post_contract.TabIndex = 106;
            btn_create_post_contract.Text = "Create post contract";
            btn_create_post_contract.UseVisualStyleBackColor = false;
            btn_create_post_contract.Click += btn_create_post_contract_Click;
            // 
            // txt_note
            // 
            txt_note.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_note.Location = new Point(769, 71);
            txt_note.Margin = new Padding(2);
            txt_note.Name = "txt_note";
            txt_note.Size = new Size(415, 65);
            txt_note.TabIndex = 104;
            txt_note.Text = "";
            // 
            // label19
            // 
            label19.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label19.AutoSize = true;
            label19.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = SystemColors.ActiveCaptionText;
            label19.Location = new Point(670, 72);
            label19.Margin = new Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new Size(49, 20);
            label19.TabIndex = 105;
            label19.Text = "Note:";
            // 
            // txt_extra_charge
            // 
            txt_extra_charge.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_extra_charge.ForeColor = SystemColors.WindowText;
            txt_extra_charge.Location = new Point(212, 113);
            txt_extra_charge.Margin = new Padding(4, 5, 4, 5);
            txt_extra_charge.Name = "txt_extra_charge";
            txt_extra_charge.Size = new Size(430, 27);
            txt_extra_charge.TabIndex = 103;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = SystemColors.ActiveCaptionText;
            label15.Location = new Point(57, 108);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(109, 20);
            label15.TabIndex = 102;
            label15.Text = "Extra charge:";
            // 
            // cb_post_payment_method
            // 
            cb_post_payment_method.AllowDrop = true;
            cb_post_payment_method.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_post_payment_method.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_post_payment_method.FormattingEnabled = true;
            cb_post_payment_method.Items.AddRange(new object[] { "Banking", "Cast payment" });
            cb_post_payment_method.Location = new Point(212, 161);
            cb_post_payment_method.Margin = new Padding(2);
            cb_post_payment_method.Name = "cb_post_payment_method";
            cb_post_payment_method.Size = new Size(430, 28);
            cb_post_payment_method.TabIndex = 97;
            // 
            // txt_post_id
            // 
            txt_post_id.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_post_id.Enabled = false;
            txt_post_id.ForeColor = SystemColors.WindowText;
            txt_post_id.Location = new Point(212, 71);
            txt_post_id.Margin = new Padding(4, 5, 4, 5);
            txt_post_id.Name = "txt_post_id";
            txt_post_id.Size = new Size(430, 27);
            txt_post_id.TabIndex = 95;
            // 
            // label17
            // 
            label17.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = SystemColors.ActiveCaptionText;
            label17.Location = new Point(56, 155);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(139, 20);
            label17.TabIndex = 100;
            label17.Text = "Payment method:";
            // 
            // label18
            // 
            label18.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = SystemColors.ActiveCaptionText;
            label18.Location = new Point(57, 62);
            label18.Margin = new Padding(4, 0, 4, 0);
            label18.Name = "label18";
            label18.Size = new Size(31, 20);
            label18.TabIndex = 99;
            label18.Text = "ID:";
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = SystemColors.ActiveCaptionText;
            label16.Location = new Point(351, 173);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(79, 20);
            label16.TabIndex = 95;
            label16.Text = "Payment:";
            // 
            // cb_payment_type
            // 
            cb_payment_type.AllowDrop = true;
            cb_payment_type.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_payment_type.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_payment_type.Enabled = false;
            cb_payment_type.FormattingEnabled = true;
            cb_payment_type.Items.AddRange(new object[] { "Male", "Female" });
            cb_payment_type.Location = new Point(450, 170);
            cb_payment_type.Margin = new Padding(2);
            cb_payment_type.Name = "cb_payment_type";
            cb_payment_type.Size = new Size(250, 28);
            cb_payment_type.TabIndex = 96;
            // 
            // ViewContract
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(1293, 659);
            Controls.Add(gb_post_contract);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(gb_car);
            Controls.Add(panel1);
            Controls.Add(groupBox1);
            Margin = new Padding(2);
            Name = "ViewContract";
            Text = "HandleContract";
            Load += HandleContract_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            gb_car.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)img_car).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            gb_post_contract.ResumeLayout(false);
            gb_post_contract.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label13;
        private TextBox txt_driver_id;
        private Label label2;
        private RichTextBox txt_address;
        private TextBox txt_phone;
        private TextBox txt_identifier;
        private ComboBox cb_gender;
        private Label label7;
        private Label label3;
        private TextBox txt_name;
        private Label lb_km;
        private Label label5;
        private Label label4;
        private Panel panel1;
        private Label label1;
        private GroupBox gb_car;
        private PictureBox img_car;
        private GroupBox groupBox2;
        private Label label11;
        private Label label12;
        private DateTimePicker txt_end_date;
        private Label label10;
        private Label label9;
        private DateTimePicker txt_start_date;
        private GroupBox groupBox3;
        private Label label8;
        private Label label6;
        private TextBox txt_pre_prices;
        private Label label14;
        private GroupBox gb_post_contract;
        private TextBox txt_pre_status;
        private ComboBox cb_pre_payment_method;
        private RichTextBox txt_note;
        private Label label19;
        private TextBox txt_extra_charge;
        private Label label15;
        private ComboBox cb_post_payment_method;
        private TextBox txt_post_id;
        private Label label17;
        private Label label18;
        private DateTimePicker txt_birth;
        private TextBox txt_pre_id;
        private Label label20;
        private Button btn_exit;
        private Button btn_create_post_contract;
        private TextBox txt_end_time;
        private MaskedTextBox txt_start_time;
        private ComboBox cb_car_status;
        private Label lb_car_status;
        private ComboBox cb_payment_type;
        private Label label16;
    }
}