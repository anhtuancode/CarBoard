﻿namespace GUI
{
    partial class ManagerUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            Add_btn = new Button();
            ID_txt = new TextBox();
            Update_btn = new Button();
            Delete_btn = new Button();
            label9 = new Label();
            data_cus = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            name = new DataGridViewTextBoxColumn();
            phone = new DataGridViewTextBoxColumn();
            address = new DataGridViewTextBoxColumn();
            gender = new DataGridViewTextBoxColumn();
            identifier = new DataGridViewTextBoxColumn();
            back_btn = new Button();
            name_txt = new TextBox();
            phone_txt = new TextBox();
            address_txt = new TextBox();
            gender_txt = new TextBox();
            identifier_txt = new TextBox();
            label3 = new Label();
            birth_lbl = new Label();
            birth_txt = new DateTimePicker();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)data_cus).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.IndianRed;
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(1198, 89);
            panel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(363, 14);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(319, 39);
            label1.TabIndex = 2;
            label1.Text = "Car Rental System";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkRed;
            label2.Location = new Point(449, 94);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(276, 31);
            label2.TabIndex = 3;
            label2.Text = "Manager Customers";
            label2.Click += label2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.DarkRed;
            label4.Location = new Point(41, 252);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(68, 25);
            label4.TabIndex = 5;
            label4.Text = "Name";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkRed;
            label5.Location = new Point(43, 346);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(74, 25);
            label5.TabIndex = 6;
            label5.Text = "Phone";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DarkRed;
            label6.Location = new Point(43, 400);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 7;
            label6.Text = "Address";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.DarkRed;
            label7.Location = new Point(43, 450);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(83, 25);
            label7.TabIndex = 8;
            label7.Text = "Gender";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.DarkRed;
            label8.Location = new Point(43, 506);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(129, 25);
            label8.TabIndex = 9;
            label8.Text = "identity card";
            // 
            // Add_btn
            // 
            Add_btn.BackColor = Color.Salmon;
            Add_btn.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            Add_btn.Location = new Point(43, 569);
            Add_btn.Margin = new Padding(4, 5, 4, 5);
            Add_btn.Name = "Add_btn";
            Add_btn.Size = new Size(101, 55);
            Add_btn.TabIndex = 10;
            Add_btn.Text = "Add";
            Add_btn.UseVisualStyleBackColor = false;
            Add_btn.Click += Add_btn_Click;
            // 
            // ID_txt
            // 
            ID_txt.ForeColor = Color.IndianRed;
            ID_txt.Location = new Point(187, 206);
            ID_txt.Margin = new Padding(4, 5, 4, 5);
            ID_txt.Name = "ID_txt";
            ID_txt.Size = new Size(231, 27);
            ID_txt.TabIndex = 11;
            // 
            // Update_btn
            // 
            Update_btn.BackColor = Color.Salmon;
            Update_btn.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            Update_btn.Location = new Point(152, 569);
            Update_btn.Margin = new Padding(4, 5, 4, 5);
            Update_btn.Name = "Update_btn";
            Update_btn.Size = new Size(101, 55);
            Update_btn.TabIndex = 17;
            Update_btn.Text = "Edit";
            Update_btn.UseVisualStyleBackColor = false;
            Update_btn.Click += Update_btn_Click;
            // 
            // Delete_btn
            // 
            Delete_btn.BackColor = Color.Salmon;
            Delete_btn.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            Delete_btn.Location = new Point(261, 569);
            Delete_btn.Margin = new Padding(4, 5, 4, 5);
            Delete_btn.Name = "Delete_btn";
            Delete_btn.Size = new Size(101, 55);
            Delete_btn.TabIndex = 18;
            Delete_btn.Text = "Delete";
            Delete_btn.UseVisualStyleBackColor = false;
            Delete_btn.Click += button3_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.DarkRed;
            label9.Location = new Point(799, 146);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(156, 25);
            label9.TabIndex = 19;
            label9.Text = "Customers List";
            // 
            // data_cus
            // 
            data_cus.BackgroundColor = SystemColors.Menu;
            data_cus.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            data_cus.Columns.AddRange(new DataGridViewColumn[] { ID, name, phone, address, gender, identifier });
            data_cus.Location = new Point(596, 178);
            data_cus.Margin = new Padding(4, 5, 4, 5);
            data_cus.Name = "data_cus";
            data_cus.RowHeadersWidth = 51;
            data_cus.Size = new Size(569, 458);
            data_cus.TabIndex = 20;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.Width = 125;
            // 
            // name
            // 
            name.HeaderText = "Name";
            name.MinimumWidth = 6;
            name.Name = "name";
            name.Width = 125;
            // 
            // phone
            // 
            phone.HeaderText = "Phone";
            phone.MinimumWidth = 6;
            phone.Name = "phone";
            phone.Width = 125;
            // 
            // address
            // 
            address.HeaderText = "Address";
            address.MinimumWidth = 6;
            address.Name = "address";
            address.Width = 125;
            // 
            // gender
            // 
            gender.HeaderText = "Gender";
            gender.MinimumWidth = 6;
            gender.Name = "gender";
            gender.Width = 125;
            // 
            // identifier
            // 
            identifier.HeaderText = "identity card";
            identifier.MinimumWidth = 6;
            identifier.Name = "identifier";
            identifier.Width = 125;
            // 
            // back_btn
            // 
            back_btn.BackColor = Color.IndianRed;
            back_btn.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            back_btn.Location = new Point(371, 569);
            back_btn.Margin = new Padding(4, 5, 4, 5);
            back_btn.Name = "back_btn";
            back_btn.Size = new Size(101, 55);
            back_btn.TabIndex = 37;
            back_btn.Text = "Back";
            back_btn.UseVisualStyleBackColor = false;
            back_btn.Click += back_btn_Click;
            // 
            // name_txt
            // 
            name_txt.ForeColor = Color.IndianRed;
            name_txt.Location = new Point(187, 254);
            name_txt.Margin = new Padding(4, 5, 4, 5);
            name_txt.Name = "name_txt";
            name_txt.Size = new Size(231, 27);
            name_txt.TabIndex = 38;
            // 
            // phone_txt
            // 
            phone_txt.ForeColor = Color.IndianRed;
            phone_txt.Location = new Point(189, 343);
            phone_txt.Margin = new Padding(4, 5, 4, 5);
            phone_txt.Name = "phone_txt";
            phone_txt.Size = new Size(231, 27);
            phone_txt.TabIndex = 39;
            // 
            // address_txt
            // 
            address_txt.ForeColor = Color.IndianRed;
            address_txt.Location = new Point(189, 397);
            address_txt.Margin = new Padding(4, 5, 4, 5);
            address_txt.Name = "address_txt";
            address_txt.Size = new Size(231, 27);
            address_txt.TabIndex = 40;
            // 
            // gender_txt
            // 
            gender_txt.ForeColor = Color.IndianRed;
            gender_txt.Location = new Point(189, 447);
            gender_txt.Margin = new Padding(4, 5, 4, 5);
            gender_txt.Name = "gender_txt";
            gender_txt.Size = new Size(231, 27);
            gender_txt.TabIndex = 41;
            // 
            // identifier_txt
            // 
            identifier_txt.ForeColor = Color.IndianRed;
            identifier_txt.Location = new Point(189, 503);
            identifier_txt.Margin = new Padding(4, 5, 4, 5);
            identifier_txt.Name = "identifier_txt";
            identifier_txt.Size = new Size(231, 27);
            identifier_txt.TabIndex = 42;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DarkRed;
            label3.Location = new Point(41, 205);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(33, 25);
            label3.TabIndex = 4;
            label3.Text = "ID";
            // 
            // birth_lbl
            // 
            birth_lbl.AutoSize = true;
            birth_lbl.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            birth_lbl.ForeColor = Color.DarkRed;
            birth_lbl.Location = new Point(43, 299);
            birth_lbl.Margin = new Padding(4, 0, 4, 0);
            birth_lbl.Name = "birth_lbl";
            birth_lbl.Size = new Size(56, 25);
            birth_lbl.TabIndex = 43;
            birth_lbl.Text = "Birth";
            // 
            // birth_txt
            // 
            birth_txt.Location = new Point(189, 297);
            birth_txt.Name = "birth_txt";
            birth_txt.Size = new Size(236, 27);
            birth_txt.TabIndex = 44;
            // 
            // ManagerUsers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1198, 732);
            Controls.Add(birth_txt);
            Controls.Add(birth_lbl);
            Controls.Add(identifier_txt);
            Controls.Add(gender_txt);
            Controls.Add(address_txt);
            Controls.Add(phone_txt);
            Controls.Add(name_txt);
            Controls.Add(back_btn);
            Controls.Add(data_cus);
            Controls.Add(label9);
            Controls.Add(Delete_btn);
            Controls.Add(Update_btn);
            Controls.Add(ID_txt);
            Controls.Add(Add_btn);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "ManagerUsers";
            Text = "ManagerUsers";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)data_cus).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.TextBox ID_txt;
        private System.Windows.Forms.Button Update_btn;
        private System.Windows.Forms.Button Delete_btn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView data_cus;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.TextBox address_txt;
        private System.Windows.Forms.TextBox gender_txt;
        private System.Windows.Forms.TextBox identifier_txt;
        private System.Windows.Forms.Label label3;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn name;
        private DataGridViewTextBoxColumn phone;
        private DataGridViewTextBoxColumn address;
        private DataGridViewTextBoxColumn gender;
        private DataGridViewTextBoxColumn identifier;
        private Label birth_lbl;
        private DateTimePicker birth_txt;
    }
}