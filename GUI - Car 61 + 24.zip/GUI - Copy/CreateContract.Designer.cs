﻿namespace GUI
{
    partial class CreateContract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cars_list = new ListView();
            car_chosing = new PictureBox();
            groupBox1 = new GroupBox();
            label13 = new Label();
            txt_birth = new DateTimePicker();
            txt_driver_id = new TextBox();
            label2 = new Label();
            txt_address = new RichTextBox();
            txt_phone = new TextBox();
            txt_identifier = new TextBox();
            cb_gender = new ComboBox();
            label7 = new Label();
            label3 = new Label();
            txt_name = new TextBox();
            lb_km = new Label();
            label5 = new Label();
            label4 = new Label();
            gb_rental_time = new GroupBox();
            cb_payment_method = new ComboBox();
            label15 = new Label();
            btn_create_contract = new Button();
            label11 = new Label();
            txt_end_time = new DateTimePicker();
            label12 = new Label();
            txt_end_date = new DateTimePicker();
            label10 = new Label();
            txt_start_time = new DateTimePicker();
            label9 = new Label();
            txt_start_date = new DateTimePicker();
            label1 = new Label();
            panel1 = new Panel();
            groupBox3 = new GroupBox();
            btn_display_cars = new Button();
            label8 = new Label();
            cb_engine_type = new ComboBox();
            label6 = new Label();
            cb_car_type = new ComboBox();
            gb_car = new GroupBox();
            cb_payment_type = new ComboBox();
            label16 = new Label();
            ((System.ComponentModel.ISupportInitialize)car_chosing).BeginInit();
            groupBox1.SuspendLayout();
            gb_rental_time.SuspendLayout();
            panel1.SuspendLayout();
            groupBox3.SuspendLayout();
            gb_car.SuspendLayout();
            SuspendLayout();
            // 
            // cars_list
            // 
            cars_list.Cursor = Cursors.Hand;
            cars_list.Location = new Point(15, 381);
            cars_list.Margin = new Padding(2);
            cars_list.MultiSelect = false;
            cars_list.Name = "cars_list";
            cars_list.Size = new Size(1271, 385);
            cars_list.TabIndex = 70;
            cars_list.UseCompatibleStateImageBehavior = false;
            cars_list.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // car_chosing
            // 
            car_chosing.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            car_chosing.Location = new Point(20, 33);
            car_chosing.Margin = new Padding(2);
            car_chosing.Name = "car_chosing";
            car_chosing.Size = new Size(204, 167);
            car_chosing.TabIndex = 72;
            car_chosing.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(cb_payment_type);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(txt_birth);
            groupBox1.Controls.Add(txt_driver_id);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txt_address);
            groupBox1.Controls.Add(txt_phone);
            groupBox1.Controls.Add(txt_identifier);
            groupBox1.Controls.Add(cb_gender);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txt_name);
            groupBox1.Controls.Add(lb_km);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Location = new Point(15, 81);
            groupBox1.Margin = new Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(2);
            groupBox1.Size = new Size(726, 220);
            groupBox1.TabIndex = 73;
            groupBox1.TabStop = false;
            groupBox1.Text = "Customer infomations";
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = SystemColors.ActiveCaptionText;
            label13.Location = new Point(22, 84);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(50, 20);
            label13.TabIndex = 94;
            label13.Text = "Birth:";
            // 
            // txt_birth
            // 
            txt_birth.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_birth.CalendarFont = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            txt_birth.Checked = false;
            txt_birth.Format = DateTimePickerFormat.Short;
            txt_birth.Location = new Point(111, 84);
            txt_birth.Margin = new Padding(2);
            txt_birth.Name = "txt_birth";
            txt_birth.Size = new Size(221, 27);
            txt_birth.TabIndex = 2;
            // 
            // txt_driver_id
            // 
            txt_driver_id.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_driver_id.ForeColor = SystemColors.WindowText;
            txt_driver_id.Location = new Point(450, 84);
            txt_driver_id.Margin = new Padding(4, 5, 4, 5);
            txt_driver_id.Name = "txt_driver_id";
            txt_driver_id.Size = new Size(250, 27);
            txt_driver_id.TabIndex = 6;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(351, 86);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 91;
            label2.Text = "Driver ID:";
            // 
            // txt_address
            // 
            txt_address.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_address.Location = new Point(450, 130);
            txt_address.Margin = new Padding(2);
            txt_address.Name = "txt_address";
            txt_address.Size = new Size(250, 27);
            txt_address.TabIndex = 7;
            txt_address.Text = "";
            // 
            // txt_phone
            // 
            txt_phone.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_phone.Location = new Point(111, 173);
            txt_phone.Margin = new Padding(2);
            txt_phone.Name = "txt_phone";
            txt_phone.Size = new Size(221, 27);
            txt_phone.TabIndex = 4;
            // 
            // txt_identifier
            // 
            txt_identifier.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_identifier.Location = new Point(450, 34);
            txt_identifier.Margin = new Padding(2);
            txt_identifier.Name = "txt_identifier";
            txt_identifier.Size = new Size(250, 27);
            txt_identifier.TabIndex = 5;
            // 
            // cb_gender
            // 
            cb_gender.AllowDrop = true;
            cb_gender.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_gender.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_gender.FormattingEnabled = true;
            cb_gender.Items.AddRange(new object[] { "Male", "Female" });
            cb_gender.Location = new Point(111, 129);
            cb_gender.Margin = new Padding(2);
            cb_gender.Name = "cb_gender";
            cb_gender.Size = new Size(221, 28);
            cb_gender.TabIndex = 3;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(351, 132);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(76, 20);
            label7.TabIndex = 85;
            label7.Text = "Address:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(20, 173);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 84;
            label3.Text = "Phone:";
            // 
            // txt_name
            // 
            txt_name.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_name.ForeColor = SystemColors.WindowText;
            txt_name.Location = new Point(111, 39);
            txt_name.Margin = new Padding(4, 5, 4, 5);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(221, 27);
            txt_name.TabIndex = 1;
            // 
            // lb_km
            // 
            lb_km.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lb_km.AutoSize = true;
            lb_km.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_km.ForeColor = SystemColors.ActiveCaptionText;
            lb_km.Location = new Point(351, 36);
            lb_km.Margin = new Padding(4, 0, 4, 0);
            lb_km.Name = "lb_km";
            lb_km.Size = new Size(78, 20);
            lb_km.TabIndex = 71;
            lb_km.Text = "Identifier:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(20, 131);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(69, 20);
            label5.TabIndex = 70;
            label5.Text = "Gender:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(22, 38);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(58, 20);
            label4.TabIndex = 69;
            label4.Text = "Name:";
            // 
            // gb_rental_time
            // 
            gb_rental_time.Controls.Add(cb_payment_method);
            gb_rental_time.Controls.Add(label15);
            gb_rental_time.Controls.Add(btn_create_contract);
            gb_rental_time.Controls.Add(label11);
            gb_rental_time.Controls.Add(txt_end_time);
            gb_rental_time.Controls.Add(label12);
            gb_rental_time.Controls.Add(txt_end_date);
            gb_rental_time.Controls.Add(label10);
            gb_rental_time.Controls.Add(txt_start_time);
            gb_rental_time.Controls.Add(label9);
            gb_rental_time.Controls.Add(txt_start_date);
            gb_rental_time.Location = new Point(1012, 81);
            gb_rental_time.Margin = new Padding(2);
            gb_rental_time.Name = "gb_rental_time";
            gb_rental_time.Padding = new Padding(2);
            gb_rental_time.Size = new Size(273, 288);
            gb_rental_time.TabIndex = 74;
            gb_rental_time.TabStop = false;
            gb_rental_time.Text = "Rental infomations";
            // 
            // cb_payment_method
            // 
            cb_payment_method.AllowDrop = true;
            cb_payment_method.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_payment_method.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_payment_method.FormattingEnabled = true;
            cb_payment_method.Items.AddRange(new object[] { "Banking", "Cast payment" });
            cb_payment_method.Location = new Point(159, 186);
            cb_payment_method.Margin = new Padding(2);
            cb_payment_method.Name = "cb_payment_method";
            cb_payment_method.Size = new Size(104, 28);
            cb_payment_method.TabIndex = 99;
            // 
            // label15
            // 
            label15.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label15.AutoSize = true;
            label15.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label15.ForeColor = SystemColors.ActiveCaptionText;
            label15.Location = new Point(8, 188);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(139, 20);
            label15.TabIndex = 100;
            label15.Text = "Payment method:";
            // 
            // btn_create_contract
            // 
            btn_create_contract.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_create_contract.BackColor = Color.SteelBlue;
            btn_create_contract.Cursor = Cursors.Hand;
            btn_create_contract.ForeColor = SystemColors.ButtonHighlight;
            btn_create_contract.Location = new Point(60, 227);
            btn_create_contract.Margin = new Padding(2);
            btn_create_contract.Name = "btn_create_contract";
            btn_create_contract.Size = new Size(167, 47);
            btn_create_contract.TabIndex = 12;
            btn_create_contract.Text = "Create contract";
            btn_create_contract.UseVisualStyleBackColor = false;
            btn_create_contract.Click += btn_create_contract_Click;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = SystemColors.ActiveCaptionText;
            label11.Location = new Point(8, 151);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(80, 20);
            label11.TabIndex = 98;
            label11.Text = "End time:";
            // 
            // txt_end_time
            // 
            txt_end_time.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_end_time.Format = DateTimePickerFormat.Time;
            txt_end_time.Location = new Point(100, 149);
            txt_end_time.Margin = new Padding(2);
            txt_end_time.Name = "txt_end_time";
            txt_end_time.Size = new Size(162, 27);
            txt_end_time.TabIndex = 11;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = SystemColors.ActiveCaptionText;
            label12.Location = new Point(8, 115);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(80, 20);
            label12.TabIndex = 96;
            label12.Text = "End date:";
            // 
            // txt_end_date
            // 
            txt_end_date.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_end_date.Format = DateTimePickerFormat.Short;
            txt_end_date.Location = new Point(100, 113);
            txt_end_date.Margin = new Padding(2);
            txt_end_date.Name = "txt_end_date";
            txt_end_date.Size = new Size(162, 27);
            txt_end_date.TabIndex = 10;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(8, 79);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(87, 20);
            label10.TabIndex = 94;
            label10.Text = "Start time:";
            // 
            // txt_start_time
            // 
            txt_start_time.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_start_time.Format = DateTimePickerFormat.Time;
            txt_start_time.Location = new Point(100, 78);
            txt_start_time.Margin = new Padding(2);
            txt_start_time.Name = "txt_start_time";
            txt_start_time.Size = new Size(162, 27);
            txt_start_time.TabIndex = 9;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(8, 44);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(87, 20);
            label9.TabIndex = 92;
            label9.Text = "Start date:";
            // 
            // txt_start_date
            // 
            txt_start_date.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txt_start_date.Format = DateTimePickerFormat.Short;
            txt_start_date.Location = new Point(100, 42);
            txt_start_date.Margin = new Padding(2);
            txt_start_date.Name = "txt_start_date";
            txt_start_date.Size = new Size(162, 27);
            txt_start_date.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(514, 18);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(263, 39);
            label1.TabIndex = 2;
            label1.Text = "Create contract";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1301, 74);
            panel1.TabIndex = 2;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btn_display_cars);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(cb_engine_type);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(cb_car_type);
            groupBox3.Location = new Point(15, 304);
            groupBox3.Margin = new Padding(2);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new Padding(2);
            groupBox3.Size = new Size(980, 64);
            groupBox3.TabIndex = 75;
            groupBox3.TabStop = false;
            groupBox3.Text = "Control";
            // 
            // btn_display_cars
            // 
            btn_display_cars.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btn_display_cars.BackColor = Color.SteelBlue;
            btn_display_cars.Cursor = Cursors.Hand;
            btn_display_cars.ForeColor = SystemColors.ButtonHighlight;
            btn_display_cars.Location = new Point(830, 19);
            btn_display_cars.Margin = new Padding(2);
            btn_display_cars.Name = "btn_display_cars";
            btn_display_cars.Size = new Size(102, 35);
            btn_display_cars.TabIndex = 91;
            btn_display_cars.Text = "Display cars";
            btn_display_cars.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(450, 27);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(101, 20);
            label8.TabIndex = 90;
            label8.Text = "Engine type:";
            // 
            // cb_engine_type
            // 
            cb_engine_type.AllowDrop = true;
            cb_engine_type.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_engine_type.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_engine_type.FormattingEnabled = true;
            cb_engine_type.Items.AddRange(new object[] { "gasoline", "diesel", "electricity", "hybrid" });
            cb_engine_type.Location = new Point(558, 24);
            cb_engine_type.Margin = new Padding(2);
            cb_engine_type.Name = "cb_engine_type";
            cb_engine_type.Size = new Size(237, 28);
            cb_engine_type.TabIndex = 89;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(85, 27);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(77, 20);
            label6.TabIndex = 88;
            label6.Text = "Car type:";
            // 
            // cb_car_type
            // 
            cb_car_type.AllowDrop = true;
            cb_car_type.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_car_type.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_car_type.FormattingEnabled = true;
            cb_car_type.Items.AddRange(new object[] { "4 seats", "5 seats", "7 seats" });
            cb_car_type.Location = new Point(168, 24);
            cb_car_type.Margin = new Padding(2);
            cb_car_type.Name = "cb_car_type";
            cb_car_type.Size = new Size(237, 28);
            cb_car_type.TabIndex = 87;
            // 
            // gb_car
            // 
            gb_car.Controls.Add(car_chosing);
            gb_car.Location = new Point(754, 81);
            gb_car.Margin = new Padding(2);
            gb_car.Name = "gb_car";
            gb_car.Padding = new Padding(2);
            gb_car.Size = new Size(241, 219);
            gb_car.TabIndex = 76;
            gb_car.TabStop = false;
            gb_car.Text = "Car";
            // 
            // cb_payment_type
            // 
            cb_payment_type.AllowDrop = true;
            cb_payment_type.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            cb_payment_type.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_payment_type.Enabled = false;
            cb_payment_type.FormattingEnabled = true;
            cb_payment_type.Items.AddRange(new object[] { "Male", "Female" });
            cb_payment_type.Location = new Point(450, 173);
            cb_payment_type.Margin = new Padding(2);
            cb_payment_type.Name = "cb_payment_type";
            cb_payment_type.Size = new Size(250, 28);
            cb_payment_type.TabIndex = 97;
            // 
            // label16
            // 
            label16.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = SystemColors.ActiveCaptionText;
            label16.Location = new Point(348, 176);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(79, 20);
            label16.TabIndex = 98;
            label16.Text = "Payment:";
            // 
            // CreateContract
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1294, 659);
            Controls.Add(gb_car);
            Controls.Add(groupBox3);
            Controls.Add(gb_rental_time);
            Controls.Add(groupBox1);
            Controls.Add(cars_list);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4);
            Name = "CreateContract";
            Text = "ManageContract";
            Load += HandleContract_Load;
            ((System.ComponentModel.ISupportInitialize)car_chosing).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            gb_rental_time.ResumeLayout(false);
            gb_rental_time.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            gb_car.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void CreateContract_FormClosed(object sender, FormClosedEventArgs e)
        {
           if(this.Owner!= null)
            {
                this.Owner.Show();
            }
        }

        #endregion
        private ListView cars_list;
        private PictureBox car_chosing;
        private GroupBox groupBox1;
        private GroupBox gb_rental_time;
        private Label label1;
        private Panel panel1;
        private TextBox txt_identifier;
        private ComboBox cb_gender;
        private Label label7;
        private Label label3;
        private TextBox txt_name;
        private Label lb_km;
        private Label label5;
        private Label label4;
        private GroupBox groupBox3;
        private TextBox txt_phone;
        private TextBox txt_driver_id;
        private Label label2;
        private RichTextBox txt_address;
        private DateTimePicker txt_start_date;
        private Button btn_display_cars;
        private Label label8;
        private ComboBox cb_engine_type;
        private Label label6;
        private ComboBox cb_car_type;
        private GroupBox gb_car;
        private Button btn_create_contract;
        private Label label11;
        private DateTimePicker txt_end_time;
        private Label label12;
        private DateTimePicker txt_end_date;
        private Label label10;
        private DateTimePicker txt_start_time;
        private Label label9;
        private Label label13;
        private DateTimePicker txt_birth;
        private ComboBox cb_payment_method;
        private Label label15;
        private ComboBox cb_payment_type;
        private Label label16;
    }
}