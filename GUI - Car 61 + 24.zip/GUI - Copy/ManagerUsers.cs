﻿using BLL;
using DTO;
using Org.BouncyCastle.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class ManagerUsers : Form
    {
        private string cus_id;
        public ManagerUsers()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen; // Hiển thị form ở giữa màn hình khi show lên
            LoadCus();
        }
        private void data_cus_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Add_btn.Enabled = false;
            Update_btn.Enabled = true;
            Delete_btn.Enabled = true;
            DataGridViewRow row = data_cus.Rows[e.RowIndex];
            name_txt.Text = row.Cells["name"].Value.ToString();
            phone_txt.Text = row.Cells["phone"].Value.ToString();
            address_txt.Text = row.Cells["address"].Value.ToString();
            gender_txt.Text = row.Cells["gender"].Value.ToString();
            identifier_txt.Text = row.Cells["identifier"].Value.ToString();

            this.cus_id = row.Cells["id"].Value.ToString();
        }
        private void LoadCus()
        {
            List<Customer> cuss = CustomerModel.GetCus();
            foreach (Customer cus in cuss)
            {
                data_cus.Rows.Add(cus.id, cus.name, cus.phone, cus.address, cus.gender, cus.identifier);
            }
        }
        private void ClearForm()
        {
            foreach (System.Windows.Forms.Control control in this.Controls)
            {
                if (!(control is Button))
                {
                    control.Text = "";
                }
            }
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Respond res = CustomerModel.deleteCus(this.cus_id);
            if (res.getStatus())
            {
                data_cus.Rows.Clear();
                LoadCus();
                MessageBox.Show(res.getDescription(), "Successfully to remove user!");
            }
            else
            {
                MessageBox.Show(res.getDescription(), "Failed to remove user!");

            }
            this.cus_id = "";
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is TextBox textBox)
                {
                    if (string.IsNullOrEmpty(textBox.Text))
                    {
                        MessageBox.Show($"Can't add new Customer with null or empty {textBox.Name}", "Error!");
                        return;
                    }
                }
            }
            Customer newCus = new Customer(ID_txt.Text, name_txt.Text, birth_txt.Value, phone_txt.Text, address_txt.Text, gender_txt.Text, identifier_txt.Text, "");
            Respond res = CustomerModel.CreateNewCustomer(newCus);
            if (res.getStatus())
            {
                data_cus.Rows.Clear();
                LoadCus();
                MessageBox.Show(res.getDescription(), "Success!");
            }
            else
            {
                MessageBox.Show(res.getDescription(), "ERROR");
            }
        }

        private void Update_btn_Click(object sender, EventArgs e)
        {
            Customer updateCus = new Customer(ID_txt.Text, name_txt.Text, birth_txt.Value, phone_txt.Text, address_txt.Text, gender_txt.Text, identifier_txt.Text, "");
            Respond res = CustomerModel.updateCus(updateCus);
            if (res.getStatus())
            {
                data_cus.Rows.Clear();
                LoadCus();
                MessageBox.Show($"Successfully to update {name_txt.Text}");
            }
            else
            {
                MessageBox.Show(res.getDescription(), "ERROR");
            }
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
