﻿using System.Windows.Forms;

namespace GUI
{
    partial class ManagerCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            txt_name = new TextBox();
            lb_hour_rent = new Label();
            lb_num_of_seats = new Label();
            lb_km = new Label();
            label5 = new Label();
            label4 = new Label();
            label9 = new Label();
            btn_delete = new Button();
            txt_hour_rent = new TextBox();
            txt_day_rent = new TextBox();
            img_car = new PictureBox();
            btn_browser_image = new Button();
            label12 = new Label();
            gb_data_form = new GroupBox();
            txt_status = new TextBox();
            label8 = new Label();
            cb_number_of_seats = new ComboBox();
            btn_export = new Button();
            txt_id = new TextBox();
            btn_edit = new Button();
            txt_km = new TextBox();
            txt_car_price = new TextBox();
            cb_engine = new ComboBox();
            label7 = new Label();
            btn_save = new Button();
            btn_exit = new Button();
            label3 = new Label();
            txt_car_year = new DateTimePicker();
            label6 = new Label();
            txt_deposit_price = new TextBox();
            label2 = new Label();
            data_cars = new DataGridView();
            image = new DataGridViewImageColumn();
            id = new DataGridViewTextBoxColumn();
            name = new DataGridViewTextBoxColumn();
            engineType = new DataGridViewTextBoxColumn();
            year = new DataGridViewTextBoxColumn();
            price = new DataGridViewTextBoxColumn();
            numberOfKm = new DataGridViewTextBoxColumn();
            rentByTime = new DataGridViewTextBoxColumn();
            RentByDate = new DataGridViewTextBoxColumn();
            depositPrice = new DataGridViewTextBoxColumn();
            numberOfSeats = new DataGridViewTextBoxColumn();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)img_car).BeginInit();
            gb_data_form.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)data_cars).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(1424, 89);
            panel1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(588, 26);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(232, 39);
            label1.TabIndex = 2;
            label1.Text = "Cars Manage";
            // 
            // txt_name
            // 
            txt_name.ForeColor = SystemColors.WindowText;
            txt_name.Location = new Point(154, 38);
            txt_name.Margin = new Padding(4, 5, 4, 5);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(870, 27);
            txt_name.TabIndex = 27;
            // 
            // lb_hour_rent
            // 
            lb_hour_rent.AutoSize = true;
            lb_hour_rent.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_hour_rent.ForeColor = SystemColors.ActiveCaptionText;
            lb_hour_rent.Location = new Point(369, 182);
            lb_hour_rent.Margin = new Padding(4, 0, 4, 0);
            lb_hour_rent.Name = "lb_hour_rent";
            lb_hour_rent.Size = new Size(100, 20);
            lb_hour_rent.TabIndex = 24;
            lb_hour_rent.Text = "Hourly price";
            // 
            // lb_num_of_seats
            // 
            lb_num_of_seats.AutoSize = true;
            lb_num_of_seats.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_num_of_seats.ForeColor = SystemColors.ActiveCaptionText;
            lb_num_of_seats.Location = new Point(367, 137);
            lb_num_of_seats.Margin = new Padding(4, 0, 4, 0);
            lb_num_of_seats.Name = "lb_num_of_seats";
            lb_num_of_seats.Size = new Size(109, 20);
            lb_num_of_seats.TabIndex = 23;
            lb_num_of_seats.Text = "Num of seats";
            // 
            // lb_km
            // 
            lb_km.AutoSize = true;
            lb_km.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            lb_km.ForeColor = SystemColors.ActiveCaptionText;
            lb_km.Location = new Point(36, 185);
            lb_km.Margin = new Padding(4, 0, 4, 0);
            lb_km.Name = "lb_km";
            lb_km.Size = new Size(103, 20);
            lb_km.TabIndex = 22;
            lb_km.Text = "Km traveled:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(36, 86);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(92, 20);
            label5.TabIndex = 21;
            label5.Text = "generation:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(36, 36);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(58, 20);
            label4.TabIndex = 20;
            label4.Text = "Name:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(706, 86);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(89, 20);
            label9.TabIndex = 34;
            label9.Text = "Daily price";
            // 
            // btn_delete
            // 
            btn_delete.BackColor = Color.SteelBlue;
            btn_delete.Cursor = Cursors.Hand;
            btn_delete.Enabled = false;
            btn_delete.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_delete.ForeColor = SystemColors.ButtonHighlight;
            btn_delete.Location = new Point(1262, 119);
            btn_delete.Margin = new Padding(4, 5, 4, 5);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(102, 41);
            btn_delete.TabIndex = 41;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = false;
            btn_delete.Click += btn_delete_Click;
            // 
            // txt_hour_rent
            // 
            txt_hour_rent.ForeColor = SystemColors.WindowText;
            txt_hour_rent.Location = new Point(484, 179);
            txt_hour_rent.Margin = new Padding(4, 5, 4, 5);
            txt_hour_rent.Name = "txt_hour_rent";
            txt_hour_rent.Size = new Size(196, 27);
            txt_hour_rent.TabIndex = 49;
            // 
            // txt_day_rent
            // 
            txt_day_rent.ForeColor = SystemColors.WindowText;
            txt_day_rent.Location = new Point(834, 83);
            txt_day_rent.Margin = new Padding(4, 5, 4, 5);
            txt_day_rent.Name = "txt_day_rent";
            txt_day_rent.Size = new Size(192, 27);
            txt_day_rent.TabIndex = 50;
            // 
            // img_car
            // 
            img_car.BackgroundImageLayout = ImageLayout.Zoom;
            img_car.Location = new Point(1060, 53);
            img_car.Margin = new Padding(4, 5, 4, 5);
            img_car.Name = "img_car";
            img_car.Size = new Size(172, 153);
            img_car.TabIndex = 51;
            img_car.TabStop = false;
            // 
            // btn_browser_image
            // 
            btn_browser_image.BackColor = Color.SteelBlue;
            btn_browser_image.Cursor = Cursors.Hand;
            btn_browser_image.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_browser_image.ForeColor = SystemColors.ButtonHighlight;
            btn_browser_image.Location = new Point(1103, 216);
            btn_browser_image.Margin = new Padding(4, 5, 4, 5);
            btn_browser_image.Name = "btn_browser_image";
            btn_browser_image.Size = new Size(87, 41);
            btn_browser_image.TabIndex = 52;
            btn_browser_image.Text = "Browse";
            btn_browser_image.UseVisualStyleBackColor = false;
            btn_browser_image.Click += btn_browser_image_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.DarkRed;
            label12.Location = new Point(1060, 22);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(71, 25);
            label12.TabIndex = 53;
            label12.Text = "Image";
            // 
            // gb_data_form
            // 
            gb_data_form.Controls.Add(txt_status);
            gb_data_form.Controls.Add(label8);
            gb_data_form.Controls.Add(cb_number_of_seats);
            gb_data_form.Controls.Add(btn_export);
            gb_data_form.Controls.Add(txt_id);
            gb_data_form.Controls.Add(btn_edit);
            gb_data_form.Controls.Add(txt_km);
            gb_data_form.Controls.Add(txt_car_price);
            gb_data_form.Controls.Add(cb_engine);
            gb_data_form.Controls.Add(label7);
            gb_data_form.Controls.Add(btn_save);
            gb_data_form.Controls.Add(btn_exit);
            gb_data_form.Controls.Add(label3);
            gb_data_form.Controls.Add(btn_delete);
            gb_data_form.Controls.Add(txt_car_year);
            gb_data_form.Controls.Add(label6);
            gb_data_form.Controls.Add(txt_deposit_price);
            gb_data_form.Controls.Add(label2);
            gb_data_form.Controls.Add(label12);
            gb_data_form.Controls.Add(btn_browser_image);
            gb_data_form.Controls.Add(img_car);
            gb_data_form.Controls.Add(txt_day_rent);
            gb_data_form.Controls.Add(txt_hour_rent);
            gb_data_form.Controls.Add(label9);
            gb_data_form.Controls.Add(txt_name);
            gb_data_form.Controls.Add(lb_hour_rent);
            gb_data_form.Controls.Add(lb_num_of_seats);
            gb_data_form.Controls.Add(lb_km);
            gb_data_form.Controls.Add(label5);
            gb_data_form.Controls.Add(label4);
            gb_data_form.Location = new Point(17, 109);
            gb_data_form.Margin = new Padding(2);
            gb_data_form.Name = "gb_data_form";
            gb_data_form.Padding = new Padding(2);
            gb_data_form.Size = new Size(1382, 264);
            gb_data_form.TabIndex = 54;
            gb_data_form.TabStop = false;
            gb_data_form.Text = "Data form";
            // 
            // txt_status
            // 
            txt_status.Location = new Point(154, 224);
            txt_status.Name = "txt_status";
            txt_status.Size = new Size(193, 27);
            txt_status.TabIndex = 74;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(36, 227);
            label8.Name = "label8";
            label8.Size = new Size(93, 20);
            label8.TabIndex = 73;
            label8.Text = "Car Check:";
            // 
            // cb_number_of_seats
            // 
            cb_number_of_seats.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_number_of_seats.FormattingEnabled = true;
            cb_number_of_seats.Items.AddRange(new object[] { "4", "5", "7" });
            cb_number_of_seats.Location = new Point(484, 132);
            cb_number_of_seats.Margin = new Padding(2);
            cb_number_of_seats.Name = "cb_number_of_seats";
            cb_number_of_seats.Size = new Size(196, 28);
            cb_number_of_seats.TabIndex = 72;
            // 
            // btn_export
            // 
            btn_export.BackColor = Color.SteelBlue;
            btn_export.Cursor = Cursors.Hand;
            btn_export.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_export.ForeColor = SystemColors.ButtonHighlight;
            btn_export.Location = new Point(1262, 210);
            btn_export.Margin = new Padding(4, 5, 4, 5);
            btn_export.Name = "btn_export";
            btn_export.Size = new Size(102, 41);
            btn_export.TabIndex = 71;
            btn_export.Text = "Export";
            btn_export.UseVisualStyleBackColor = false;
            btn_export.Click += btn_export_Click;
            // 
            // txt_id
            // 
            txt_id.Enabled = false;
            txt_id.ForeColor = SystemColors.WindowText;
            txt_id.Location = new Point(783, 180);
            txt_id.Margin = new Padding(2);
            txt_id.Name = "txt_id";
            txt_id.Size = new Size(242, 27);
            txt_id.TabIndex = 70;
            // 
            // btn_edit
            // 
            btn_edit.BackColor = Color.SteelBlue;
            btn_edit.Cursor = Cursors.Hand;
            btn_edit.Enabled = false;
            btn_edit.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_edit.ForeColor = SystemColors.ButtonHighlight;
            btn_edit.Location = new Point(1262, 70);
            btn_edit.Margin = new Padding(4, 5, 4, 5);
            btn_edit.Name = "btn_edit";
            btn_edit.Size = new Size(102, 43);
            btn_edit.TabIndex = 69;
            btn_edit.Text = "Update";
            btn_edit.UseVisualStyleBackColor = false;
            btn_edit.Click += btn_edit_Click;
            // 
            // txt_km
            // 
            txt_km.Location = new Point(154, 180);
            txt_km.Margin = new Padding(2);
            txt_km.Name = "txt_km";
            txt_km.Size = new Size(193, 27);
            txt_km.TabIndex = 68;
            // 
            // txt_car_price
            // 
            txt_car_price.ForeColor = SystemColors.WindowText;
            txt_car_price.Location = new Point(486, 89);
            txt_car_price.Margin = new Padding(2);
            txt_car_price.Name = "txt_car_price";
            txt_car_price.Size = new Size(194, 27);
            txt_car_price.TabIndex = 67;
            // 
            // cb_engine
            // 
            cb_engine.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_engine.FormattingEnabled = true;
            cb_engine.Items.AddRange(new object[] { "gasoline", "diesel", "electricity", "hybrid" });
            cb_engine.Location = new Point(154, 131);
            cb_engine.Margin = new Padding(2);
            cb_engine.Name = "cb_engine";
            cb_engine.Size = new Size(192, 28);
            cb_engine.TabIndex = 66;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(369, 90);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(78, 20);
            label7.TabIndex = 65;
            label7.Text = "Car price";
            // 
            // btn_save
            // 
            btn_save.BackColor = Color.SteelBlue;
            btn_save.Cursor = Cursors.Hand;
            btn_save.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_save.ForeColor = SystemColors.ButtonHighlight;
            btn_save.Location = new Point(1262, 23);
            btn_save.Margin = new Padding(4, 5, 4, 5);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(102, 43);
            btn_save.TabIndex = 54;
            btn_save.Text = "Add";
            btn_save.UseVisualStyleBackColor = false;
            btn_save.Click += btn_save_Click;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = Color.SteelBlue;
            btn_exit.Cursor = Cursors.Hand;
            btn_exit.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_exit.ForeColor = SystemColors.ButtonHighlight;
            btn_exit.Location = new Point(1262, 165);
            btn_exit.Margin = new Padding(4, 5, 4, 5);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(102, 41);
            btn_exit.TabIndex = 42;
            btn_exit.Text = "Exit";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(34, 133);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(65, 20);
            label3.TabIndex = 63;
            label3.Text = "Engine:";
            // 
            // txt_car_year
            // 
            txt_car_year.Location = new Point(154, 86);
            txt_car_year.Margin = new Padding(2);
            txt_car_year.Name = "txt_car_year";
            txt_car_year.Size = new Size(193, 27);
            txt_car_year.TabIndex = 62;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(707, 132);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(109, 20);
            label6.TabIndex = 61;
            label6.Text = "Deposit price";
            // 
            // txt_deposit_price
            // 
            txt_deposit_price.ForeColor = SystemColors.WindowText;
            txt_deposit_price.Location = new Point(834, 132);
            txt_deposit_price.Margin = new Padding(2);
            txt_deposit_price.Name = "txt_deposit_price";
            txt_deposit_price.Size = new Size(191, 27);
            txt_deposit_price.TabIndex = 60;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Enabled = false;
            label2.Font = new Font("Microsoft Sans Serif", 10.125F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(706, 185);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(26, 20);
            label2.TabIndex = 59;
            label2.Text = "ID";
            // 
            // data_cars
            // 
            data_cars.ColumnHeadersHeight = 46;
            data_cars.Columns.AddRange(new DataGridViewColumn[] { image, id, name, engineType, year, price, numberOfKm, rentByTime, RentByDate, depositPrice, numberOfSeats });
            data_cars.Cursor = Cursors.Hand;
            data_cars.Location = new Point(17, 389);
            data_cars.Margin = new Padding(2);
            data_cars.MultiSelect = false;
            data_cars.Name = "data_cars";
            data_cars.RowHeadersWidth = 82;
            data_cars.RowTemplate.Height = 41;
            data_cars.Size = new Size(1382, 379);
            data_cars.TabIndex = 55;
            data_cars.CellContentClick += data_cars_CellContentClick;
            // 
            // image
            // 
            image.HeaderText = "Image";
            image.MinimumWidth = 10;
            image.Name = "image";
            image.Width = 200;
            // 
            // id
            // 
            id.HeaderText = "ID";
            id.MinimumWidth = 10;
            id.Name = "id";
            id.Width = 200;
            // 
            // name
            // 
            name.HeaderText = "Name";
            name.MinimumWidth = 10;
            name.Name = "name";
            name.Width = 200;
            // 
            // engineType
            // 
            engineType.HeaderText = "Engine type";
            engineType.MinimumWidth = 10;
            engineType.Name = "engineType";
            engineType.Width = 200;
            // 
            // year
            // 
            year.HeaderText = "Year";
            year.MinimumWidth = 10;
            year.Name = "year";
            year.Width = 200;
            // 
            // price
            // 
            price.HeaderText = "Price";
            price.MinimumWidth = 10;
            price.Name = "price";
            price.Width = 200;
            // 
            // numberOfKm
            // 
            numberOfKm.HeaderText = "Km traveled";
            numberOfKm.MinimumWidth = 10;
            numberOfKm.Name = "numberOfKm";
            numberOfKm.Width = 200;
            // 
            // rentByTime
            // 
            rentByTime.HeaderText = "Houry price";
            rentByTime.MinimumWidth = 10;
            rentByTime.Name = "rentByTime";
            rentByTime.Width = 200;
            // 
            // RentByDate
            // 
            RentByDate.HeaderText = "Daily price";
            RentByDate.MinimumWidth = 10;
            RentByDate.Name = "RentByDate";
            RentByDate.Width = 200;
            // 
            // depositPrice
            // 
            depositPrice.HeaderText = "Deposit price";
            depositPrice.MinimumWidth = 10;
            depositPrice.Name = "depositPrice";
            depositPrice.Width = 200;
            // 
            // numberOfSeats
            // 
            numberOfSeats.HeaderText = "Number of seats";
            numberOfSeats.MinimumWidth = 10;
            numberOfSeats.Name = "numberOfSeats";
            numberOfSeats.Width = 200;
            // 
            // ManagerCars
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1424, 659);
            Controls.Add(data_cars);
            Controls.Add(gb_data_form);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Margin = new Padding(4, 5, 4, 5);
            Name = "ManagerCars";
            Text = " ";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)img_car).EndInit();
            gb_data_form.ResumeLayout(false);
            gb_data_form.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)data_cars).EndInit();
            ResumeLayout(false);
        }

        private void ManagerCars_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.Owner != null)
            {
                this.Owner.Show();
            }
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lb_hour_rent;
        private System.Windows.Forms.Label lb_num_of_seats;
        private System.Windows.Forms.Label lb_km;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_hour_rent;
        private System.Windows.Forms.TextBox txt_day_rent;
        private System.Windows.Forms.PictureBox img_car;
        private System.Windows.Forms.Button btn_browser_image;
        private System.Windows.Forms.Label label12;
        private GroupBox gb_data_form;
        private Button btn_save;
        private Label label6;
        private TextBox txt_deposit_price;
        private DateTimePicker txt_car_year;
        private Label label3;
        private Label label7;
        private ComboBox cb_engine;
        private TextBox txt_car_price;
        private Button btn_exit;
        private DataGridView data_cars;
        private TextBox txt_km;
        private DataGridViewImageColumn image;
        private DataGridViewTextBoxColumn id;
        private DataGridViewTextBoxColumn name;
        private DataGridViewTextBoxColumn engineType;
        private DataGridViewTextBoxColumn year;
        private DataGridViewTextBoxColumn price;
        private DataGridViewTextBoxColumn numberOfKm;
        private DataGridViewTextBoxColumn rentByTime;
        private DataGridViewTextBoxColumn RentByDate;
        private DataGridViewTextBoxColumn depositPrice;
        private DataGridViewTextBoxColumn numberOfSeats;
        private Button btn_edit;
        private TextBox txt_id;
        private Button btn_export;
        private ComboBox cb_number_of_seats;
        private Label label8;
        private TextBox txt_status;
    }
}